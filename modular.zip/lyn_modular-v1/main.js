// var square = require('./lib').square;
// var diag = require('./lib').diag;
// console.log(square(11)); // 121
// console.log(diag(4, 3)); // 5



var lib = require('./lib')

console.log(lib.square(11)); // 121
console.log(lib.diag(4, 3)); // 5